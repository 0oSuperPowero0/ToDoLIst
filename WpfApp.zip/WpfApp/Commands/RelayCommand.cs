﻿using System;
using System.Windows.Input;

namespace WpfApp.Commands;

// Zwischenlink wpf button -> Methode
public class RelayCommand : ICommand
{
	//field
	private readonly Action _execute; 
	private readonly Func<bool>? _canExecute; 

	//Konstruktor
	public RelayCommand (Action execute, Func<bool>? canExecute = null)
	{
		_execute = execute;
		_canExecute = canExecute;
	}

	public bool CanExecute(object? parameter)// aktivieren oder deaktivieren den Button
	{
		return _canExecute == null || _canExecute();
	}

	public void Execute(object? parameter) //speichern die auszuführende Methode
	{
		_execute();
	}

	public event EventHandler? CanExecuteChanged; // informieren Zustandsänderung

	public void RaiseCanExectueChanged() //benachrichtigen WPF, CanExecute ernuet zu überprüfen
	{
		CanExecuteChanged?.Invoke(this, EventArgs.Empty);
	}
}
